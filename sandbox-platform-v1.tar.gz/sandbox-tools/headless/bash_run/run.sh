#!/usr/bin/env bash
# bash_run — runs a bash script inside the sandbox.
# Input (TOOL_INPUT env): {"script": "echo hello", "timeout": 30}
# Output (stdout, JSON): {"stdout": "...", "stderr": "...", "exit_code": 0}

set -euo pipefail

INPUT="${TOOL_INPUT:-{}}"

SCRIPT=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('script',''))" 2>/dev/null || echo "")
TIMEOUT=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('timeout',30))" 2>/dev/null || echo "30")

if [ -z "$SCRIPT" ]; then
  echo '{"stdout":"","stderr":"script field is required","exit_code":1}'
  exit 0
fi

TMPFILE=$(mktemp /tmp/bash_run_XXXXXX.sh)
echo "$SCRIPT" > "$TMPFILE"
chmod +x "$TMPFILE"

STDOUT_FILE=$(mktemp)
STDERR_FILE=$(mktemp)

EXIT_CODE=0
timeout "$TIMEOUT" bash "$TMPFILE" >"$STDOUT_FILE" 2>"$STDERR_FILE" || EXIT_CODE=$?

STDOUT=$(cat "$STDOUT_FILE")
STDERR=$(cat "$STDERR_FILE")

rm -f "$TMPFILE" "$STDOUT_FILE" "$STDERR_FILE"

python3 -c "
import json
print(json.dumps({'stdout': '''$STDOUT''', 'stderr': '''$STDERR''', 'exit_code': $EXIT_CODE}))
"
