# Active Context
_File ini wajib di-update setiap mulai dan selesai sesi kerja._

## Sedang dikerjakan sekarang
> Baru selesai: setup `.clinerules` + `memory-bank` yang benar

**Next task**: Implementasi step 5 upload output + buat minimal `platform-tools` image

---

## Keputusan arsitektur yang sudah diambil — jangan ubah tanpa diskusi

| Keputusan | Alasan |
|-----------|--------|
| Redis Lua token bucket untuk rate limit | Atomic — tidak ada race condition vs INCR+EXPIRE |
| `db.Migrate(ctx)` auto-run di startup | Tidak perlu step manual, aman idempotent |
| JWT `nil` pubkey = dev mode | Gateway bisa jalan tanpa setup RSA key di local |
| SandboxClaim name = `"job-" + jobID` | Deterministik, mudah di-debug dan cleanup |
| `platform.phase` di viper config | Bisa ganti isolation level tanpa rebuild binary |
| Tidak ada ORM — pgx/v5 langsung | Kontrol penuh atas query, tidak ada magic |
| `PipelineContext` sebagai shared state antar steps | Tidak ada coupling langsung antar steps |

---

## Known issues / bugs aktif

### Bug 1 — Tier detection di rate limiter selalu "async"
**File**: `internal/gateway/middleware/ratelimit.go` fungsi `tierFromPath()`  
**Problem**: Selalu return `"async"` karena tidak bisa baca request body (sudah di-consume handler)  
**Fix yang perlu dilakukan**: Tambah middleware sebelum rate limiter yang extract `tier` dari body ke request context

### Bug 2 — TOOL_RUNNER_IMAGE tidak di-wrap viper
**File**: `cmd/orchestrator/main.go` fungsi `bootstrapSandboxInfra()`  
**Problem**: `os.Getenv("TOOL_RUNNER_IMAGE")` bypass viper, inkonsisten dengan pola config lain  
**Fix**: Tambah key `sandbox.tool_runner_image` ke `config/app.yaml` dan gunakan `viper.GetString()`

### Bug 3 — grpc.WithTimeout deprecated
**File**: `execution/async/steps/4_execute_code.go`  
**Problem**: `grpc.WithTimeout` deprecated di grpc-go v1.64+  
**Fix**: Gunakan `grpc.NewClient()` + pass context dengan deadline

---

## Konteks yang perlu diingat untuk sesi berikutnya

1. **Step 5 upload output** — `pCtx.OutputPrefix` sudah diset, tinggal:
   - Dial sandbox gRPC, panggil `ExecutionService.ListOutputFiles()`
   - Untuk tiap file: stream isinya → `minio.Client.Put()`
   - Ini butuh `make proto` dijalankan dulu untuk generate gRPC client code

2. **platform-tools image** belum ada sama sekali. Kalau `make test-job` dijalankan sekarang:
   - Step 1 OK (SandboxClaim dibuat, pod dari warm pool)
   - Step 4 GAGAL (gRPC dial timeout — tidak ada server di pod:50051)
   - Minimal image butuh: Go/Python binary yang listen gRPC 50051 + implement `Execute()` RPC

3. **Makefile `make proto`** — perlu protoc ter-install di machine. Kalau tidak ada, gunakan Docker:
   ```bash
   docker run --rm -v $(pwd):/workspace ghcr.io/grpc/grpc:latest \
     protoc --go_out=/workspace --go-grpc_out=/workspace api/proto/execution.proto
   ```
