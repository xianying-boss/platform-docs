# Project Brief

## Satu kalimat
Platform-core adalah **control plane + execution engine** yang memungkinkan AI agent menjalankan tools (kode, browser, shell) di dalam isolated Kubernetes sandbox secara aman dan cepat.

## Problem yang diselesaikan
AI agent perlu mengeksekusi kode arbitrari — Python, shell, browser automation — tanpa risiko keamanan. Platform ini menyediakan isolated execution environment dengan warm pool agar latensi tetap rendah.

## Dua binary
| Binary | Port | Fungsi |
|--------|------|--------|
| `cmd/gateway` | `:8080` | Terima HTTP request, auth JWT, rate limit, push ke Redis queue |
| `cmd/orchestrator` | — | Consume queue, alokasi sandbox K8s, jalankan tool via gRPC |

## Sandbox primitive (kubernetes-sigs/agent-sandbox)
- **SandboxTemplate** — blueprint pod: image, resources, runtime class
- **SandboxWarmPool** — N pod pre-warmed, siap dialokasikan dalam < 200ms
- **SandboxClaim** — "saya butuh 1 sandbox untuk job ini" → sistem alokasi dari pool

## Isolation phases
| Phase | Runtime | Dipakai di |
|-------|---------|-----------|
| 2 | runc | Local dev, kind |
| 3 | gVisor | Staging |
| 4 | Firecracker (kata-fc) | Production |

## Repo terkait
- `platform-core` — repo ini
- `platform-tools` — container images yang jalan di dalam sandbox (tool runners, belum ada)
