# System Patterns

## Alur request end-to-end

```
POST /v1/execute
      │
      ▼
[middleware/auth.go]          JWT RS256 validate (nil pubkey = dev mode skip)
      │
      ▼
[middleware/ratelimit.go]     Redis Lua token bucket per agentID+tier
      │
      ▼
[handlers/execution.go]       Buat job row di PostgreSQL (status=pending)
      │                        Push ke Redis stream "code-jobs"
      │                        Return {"job_id":"..."} HTTP 202
      ▼
[queue/consumer.go]           XREADGROUP — ambil 1 message
      │
      ▼
[execution/async/runner.go]   Dispatch ke pipeline
      │
      ▼
[execution/async/pipeline.go] 5 steps berurutan:
      │
      ├─ Step 1: CreateClaim("job-{jobID}", templateName)
      │          WaitForClaim → Sandbox.Status.Ready = true
      │          Set pCtx.GRPCAddr = "{sandbox}.{ns}.svc.cluster.local:50051"
      │
      ├─ Step 2: Parse input_json["artifacts"] → presign MinIO URLs
      │          Inject sebagai ARTIFACT_N_URL env var di pCtx.EnvVars
      │
      ├─ Step 3: MountSkill (no-op phase 2)
      │
      ├─ Step 4: grpc.NewClient(pCtx.GRPCAddr)
      │          ExecutionService.Execute(JobID, ToolName, InputJSON)
      │          Set pCtx.Logs dari stdout+stderr
      │
      └─ Step 5: Set pCtx.OutputPrefix = "jobs/{jobID}/output/"
                 TODO: ListOutputFiles gRPC → upload ke MinIO
      │
      ▼
[storage/jobs.go]             Complete(jobID, outputRef, durationMs, logs)
      │
      ▼
[queue/consumer.go]           XAck → message selesai
```

## PipelineContext — satu-satunya cara steps berkomunikasi

```go
// execution/async/steps/context.go
type PipelineContext struct {
    Job          *queue.JobMessage  // immutable input
    ClaimName    string             // "job-{jobID}" — diset di Step 1
    SandboxName  string             // nama sandbox K8s — diset di Step 1
    GRPCAddr     string             // host:port gRPC — diset di Step 1
    EnvVars      []corev1.EnvVar    // artifact URLs — diset di Step 2
    Logs         string             // stdout+stderr — diset di Step 4
    OutputPrefix string             // MinIO prefix — diset di Step 5
    StartTime    time.Time
}
```

**Aturan**: Steps tidak boleh memanggil satu sama lain. Komunikasi hanya lewat PipelineContext.

## Sandbox cleanup — pola wajib

```go
// Di setiap titik kegagalan, cleanup HARUS berjalan
func (p *Pipeline) Run(ctx context.Context, msg queue.JobMessage) error {
    // Step 1 — jika gagal, belum ada sandbox, langsung fail
    if err := s1.Run(ctx, pCtx); err != nil {
        return p.fail(ctx, jobID, "create_runtime", err)
    }

    // Setelah step 1 sukses, semua kegagalan berikutnya harus cleanup
    if err := s2.Run(ctx, pCtx); err != nil {
        p.cleanup(ctx, jobID)  // DeleteClaim
        return p.fail(ctx, jobID, "download_artifact", err)
    }
    // ... dst untuk step 3, 4, 5

    p.cleanup(ctx, jobID)  // cleanup juga setelah sukses
    return nil
}
```

## SandboxClient — satu-satunya gateway ke K8s

```
internal/orchestration/code_controller/sandbox_client.go

EnsureTemplate(name, image, runtimeClass, limits)  → create or update idempotent
EnsureWarmPool(poolName, templateName, replicas)    → create or update idempotent
CreateClaim(jobID, templateName, labels)            → buat SandboxClaim "job-{jobID}"
WaitForClaim(claimName, timeout)                    → poll sampai Sandbox Ready
DeleteClaim(jobID)                                  → delete claim, ignore NotFound
PauseSandbox(name)                                  → replicas = 0
ResumeSandbox(name)                                 → replicas = 1
GetSandboxGRPCAddr(sandboxName)                     → "name.ns.svc.cluster.local:50051"
```

## Dev mode — nil JWT pubkey

```go
// middleware/auth.go
func Auth(publicKeyPEM []byte) func(http.Handler) http.Handler {
    if publicKeyPEM == nil {
        // Tidak ada key file → skip validasi, inject "dev-agent"
        return func(next http.Handler) http.Handler {
            return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
                ctx := context.WithValue(r.Context(), ContextKeyAgentID, "dev-agent")
                next.ServeHTTP(w, r.WithContext(ctx))
            })
        }
    }
    // ... RS256 validation
}
```

Aktif otomatis jika `vault.jwt_public_key_path` tidak ada. Tidak perlu config khusus.

## Auto-migration — jalan di startup

```go
// cmd/gateway/main.go dan cmd/orchestrator/main.go
db, _ := storage.Connect(ctx, dsn)
if err := db.Migrate(ctx); err != nil { os.Exit(1) }
```

`db.Migrate()` membaca `internal/storage/migrations/*.sql` via `embed.FS`, tracks applied migrations di tabel `schema_migrations`. Safe dijalankan berkali-kali.

## Dependency graph — tidak boleh dibalik

```
cmd/
 └── internal/gateway
 └── internal/orchestration  
 └── internal/storage         (tidak import queue)
 └── internal/queue           (tidak import storage)
 └── internal/minio
 └── internal/telemetry

execution/async/
 └── internal/orchestration/code_controller
 └── internal/storage
 └── internal/minio
 └── internal/telemetry
 (DILARANG import internal/gateway)
```

## Naming conventions

| Entitas | Format | Contoh |
|---------|--------|--------|
| SandboxClaim | `job-{uuid}` | `job-550e8400-e29b-41d4` |
| MinIO input | `jobs/{jobID}/input/{file}` | |
| MinIO output | `jobs/{jobID}/output/{file}` | |
| MinIO artifact | `artifacts/{artifactID}` | |
| Redis rate limit key | `ratelimit:{agentID}:{tier}` | |
| OTel span | `step.{nama}` | `step.create_runtime` |
| SandboxTemplate | `{tier}-{phase}` | `code-headless-runc` |
| WarmPool | `{template}-pool` | `code-headless-runc-pool` |
