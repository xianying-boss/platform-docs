# Tech Context

## Go dependencies (go.mod)

| Package | Versi | Dipakai untuk |
|---------|-------|--------------|
| `github.com/go-chi/chi/v5` | v5.1.0 | HTTP router |
| `github.com/golang-jwt/jwt/v5` | v5.2.1 | JWT RS256 parse/validate |
| `github.com/google/uuid` | v1.6.0 | Generate job ID |
| `github.com/jackc/pgx/v5` | v5.6.0 | PostgreSQL client (pgxpool) |
| `github.com/minio/minio-go/v7` | v7.0.74 | S3-compatible object storage |
| `github.com/redis/go-redis/v9` | v9.6.1 | Redis Streams + Lua scripts |
| `github.com/spf13/viper` | v1.19.0 | Config file + env var |
| `go.opentelemetry.io/otel` | v1.28.0 | Distributed tracing |
| `go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc` | v1.28.0 | OTLP export |
| `google.golang.org/grpc` | v1.64.0 | gRPC client ke sandbox pod |
| `google.golang.org/protobuf` | v1.34.2 | Protobuf serialization |
| `k8s.io/api` + `k8s.io/apimachinery` + `k8s.io/client-go` | v0.31.0 | Kubernetes client |
| `sigs.k8s.io/agent-sandbox` | v0.1.1 | CRD types (Sandbox, SandboxTemplate, dll) |
| `sigs.k8s.io/controller-runtime` | v0.19.0 | K8s client wrapper |

## agent-sandbox API groups
```
Core CRDs:
  agents.x-k8s.io/v1alpha1
  → import "sigs.k8s.io/agent-sandbox/api/v1alpha1"
  → resources: Sandbox

Extensions CRDs:
  extensions.agents.x-k8s.io/v1alpha1
  → import "sigs.k8s.io/agent-sandbox/extensions/api/v1alpha1"
  → resources: SandboxTemplate, SandboxClaim, SandboxWarmPool
```

## Semua config keys (config/app.yaml)

```yaml
gateway:
  port: 8080
  shutdown_timeout_seconds: 30

platform:
  phase: 2                    # 2=runc | 3=gvisor | 4=kata-fc
  namespace: default

queue:
  redis_url: redis://localhost:6379
  code_stream: code-jobs
  desktop_stream: desktop-jobs
  consumer_group: platform-core
  block_ms: 2000

storage:
  postgres_dsn: postgres://platform:platform@localhost:5432/platform?sslmode=disable
  minio_endpoint: localhost:9000
  minio_access_key: minioadmin
  minio_secret_key: minioadmin
  minio_bucket: platform
  minio_use_ssl: false

vault:
  jwt_public_key_path: /etc/platform/jwt_public.pem  # tidak ada = dev mode

telemetry:
  otlp_endpoint: http://otel-collector:4317
  service_name: platform-core
  insecure: true

rate_limits:
  wasm_per_minute: 100
  async_per_minute: 20
  desktop_per_minute: 5
```

## Env var overrides (Viper AutomaticEnv, underscore separator)
```bash
PLATFORM_PHASE=3
PLATFORM_NAMESPACE=production
STORAGE_POSTGRES_DSN=postgres://...
QUEUE_REDIS_URL=redis://prod:6379
VAULT_JWT_PUBLIC_KEY_PATH=/run/secrets/jwt_public.pem
```

## Local dev services
| Service | Port | Credentials |
|---------|------|-------------|
| PostgreSQL 16 | 5432 | user=platform pw=platform db=platform |
| Redis 7 | 6379 | tanpa password |
| MinIO | 9000 (API) 9001 (console) | minioadmin / minioadmin |

## PostgreSQL tables
```sql
tools              -- registry tool (tool_name PK, tier, container_image, timeout_ms)
jobs               -- eksekusi (job_id UUID PK, status, input_json, output_ref, logs)
artifacts          -- file I/O (artifact_id UUID PK, job_id FK, minio_key)
desktop_sessions   -- GUI session (session_id UUID PK, sandbox_name, vnc_url)
rate_limit_state   -- fallback jika Redis down
audit_log          -- append-only event log
schema_migrations  -- tracking migrasi yang sudah diapply
```

## gRPC service (api/proto/execution.proto)
```protobuf
service ExecutionService {
  rpc Execute(ExecuteRequest)           returns (ExecuteResult);
  rpc TakeScreenshot(ScreenshotRequest) returns (ScreenshotResult);
  rpc SendInput(InputEvent)             returns (InputAck);
  rpc ListOutputFiles(FileListRequest)  returns (FileListResult);
}
```
Generated code belum ada — jalankan `make proto` untuk generate ke `api/proto/executionv1/`.

## SandboxTemplate yang sudah ada di K8s
| Nama | Phase | RuntimeClass | CPU | Mem |
|------|-------|-------------|-----|-----|
| code-headless-runc | 2 | runc | 2 | 2Gi |
| code-headless-gvisor | 3 | gvisor | 2 | 2Gi |
| code-headless-kata-fc | 4 | kata-fc | 4 | 4Gi |
| desktop-kata-fc | 4 | kata-fc | 4 | 4Gi |

## WarmPool yang sudah ada
| Nama | Template | Replicas |
|------|----------|---------|
| code-headless-runc-pool | code-headless-runc | 5 |
| code-headless-gvisor-pool | code-headless-gvisor | 5 |
| code-headless-kata-fc-pool | code-headless-kata-fc | 3 |
| desktop-warm-pool | desktop-kata-fc | 3 |
