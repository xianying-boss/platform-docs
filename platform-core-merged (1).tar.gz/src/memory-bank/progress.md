# Progress

## Status keseluruhan

```
Control Plane    [████████████████░░]  85%
Execution Plane  [██████████████░░░░]  70%
Storage / Infra  [████████████████████] 100%
Tests            [░░░░░░░░░░░░░░░░░░░]   0%
```

---

## Apa yang sudah jalan ✅

### Gateway (cmd/gateway)
- HTTP server Chi v5, port 8080, graceful shutdown 30s
- JWT RS256 middleware — nil pubkey = dev mode otomatis
- Redis Lua rate limiter per agentID+tier
- OTel span per request
- `POST /v1/execute` → buat job di DB + push ke Redis stream
- `GET /v1/jobs/:id` → baca status job dari DB
- `GET /v1/health` → `{"status":"ok"}`
- Auto-migrate DB di startup

### Orchestrator (cmd/orchestrator)
- Bootstrap `SandboxTemplate` + `SandboxWarmPool` ke K8s di startup
- Redis consumer group `platform-core` di stream `code-jobs`
- Dispatch job ke 5-step pipeline

### Pipeline (execution/async)
- **Step 1** — CreateSandboxClaim + poll WaitForClaim (timeout 30s) ✅
- **Step 2** — Parse artifact IDs dari input JSON → presign MinIO URLs → env vars ✅
- **Step 3** — MountSkill no-op (phase 2) ✅
- **Step 4** — gRPC dial sandbox pod + kirim ExecuteRequest ✅ *(gagal jika tidak ada tool runner image)*
- **Step 5** — Set OutputPrefix ⚠️ *(upload file belum diimplementasi)*

### Storage
- PostgreSQL: 4 migrations (tools, jobs, artifacts, sessions, audit_log)
- `JobStore`: Create, SetRunning, Complete, Fail, Get
- `ArtifactStore`: Create, ListByJob
- `SessionStore`: Create, Get, UpdateStatus, Destroy
- `AuditStore`: Write (append-only)
- Auto-migration via embed.FS ✅

### Infra / Config
- `docker-compose.yml` — postgres + redis + minio ✅
- `config/crd/sandbox_templates.yaml` — 4 templates ✅
- `config/crd/sandbox_warm_pools.yaml` — 4 pools ✅
- `config/rbac/orchestrator_role.yaml` — ClusterRole + binding ✅
- `hack/kind-config.yaml` — local kind cluster ✅
- `Makefile` — 13 targets simpel ✅
- `.clinerules` + `memory-bank/` ✅

---

## Yang belum ada ❌

### Prioritas 1 — Butuh ini untuk end-to-end test
- [ ] `make proto` → generate `api/proto/executionv1/*.go`
- [ ] Step 5: implementasi `ListOutputFiles` gRPC + upload ke MinIO
- [ ] `platform-tools` minimal image (Python + gRPC server di :50051)

### Prioritas 2 — Fungsionalitas tambahan
- [ ] Fix bug tier detection di rate limiter
- [ ] Fix `TOOL_RUNNER_IMAGE` → pindah ke viper config
- [ ] Fix `grpc.WithTimeout` deprecated → context deadline
- [ ] `handlers/artifacts.go` — upload/download artifact endpoint
- [ ] `handlers/sessions.go` — desktop session CRUD endpoint
- [ ] Retry logic pipeline (max 3x untuk step 1 timeout)
- [ ] Callback URL — POST result ke `job.CallbackURL` setelah selesai

### Prioritas 3 — Masa depan
- [ ] `internal/orchestration/desktop_controller/` — GUI session lifecycle
- [ ] `internal/orchestration/wasm_controller/` — in-process WASM pool
- [ ] `cmd/wasm-worker`
- [ ] `tests/integration/` — pakai testcontainers-go
- [ ] `/admin/pools/:name/scale` endpoint
- [ ] Phase 3: gVisor (tinggal ganti config, code sudah siap)
- [ ] Phase 4: kata-fc

---

## Milestone

### M1: Smoke test jalan ← SEKARANG di sini
- [x] `make setup` tidak error
- [x] `make gateway` → listening :8080
- [x] `make ping` → `{"status":"ok"}`
- [x] `make test-job` → dapat `job_id` (202)
- [ ] `GET /v1/jobs/:id` → status `completed` ← **BELUM**

### M2: End-to-end dengan tool runner
- [ ] `make proto` sukses
- [ ] Build + push minimal platform-tools image
- [ ] `kind load docker-image platform-tools:dev`
- [ ] Submit job → completed → output tersedia di MinIO

### M3: Production-ready
- [ ] Phase 3 gVisor jalan
- [ ] Integration tests lulus
- [ ] Semua known bugs terfix

---

## Changelog singkat

| Versi | Perubahan |
|-------|-----------|
| v0.1 | Initial scaffold dari platform-core-prompt.md |
| v0.2 | Merge dengan zip: sandbox_client real CRD types, Lua ratelimit, RS256 JWT |
| v0.3 | Tambah auto-migration, storage artifacts/sessions/audit |
| v0.4 | Simplify Makefile 13 targets |
| v0.5 | `.clinerules` + `memory-bank/` proper format |
