# Product Context

## Kenapa platform ini ada?
AI agent (seperti Claude, GPT-based agent) sering butuh menjalankan kode untuk menyelesaikan task — analisis data, scraping, automation. Tanpa isolated execution, ini berbahaya karena kode bisa mengakses filesystem host, network internal, atau credentials.

## User journey
```
Agent kirim request
  → Gateway validasi JWT + rate limit
  → Job masuk queue (async, agent tidak perlu tunggu)
  → Agent poll GET /v1/jobs/:id untuk hasil
  → Orchestrator alokasi sandbox → jalankan tool → simpan output ke MinIO
  → Agent ambil output via presigned URL
```

## Tiers eksekusi
| Tier | Kapan dipakai | Contoh tools |
|------|--------------|-------------|
| `wasm` | Komputasi ringan, < 20ms | Kalkulasi, string processing |
| `headless` | Kode dengan I/O, < 5 menit | python_run, bash_run, pip install |
| `gui` | Butuh tampilan layar | browser_automation, screenshot |

## Perilaku yang diharapkan user
- Submit job → dapat `job_id` langsung (< 100ms)
- Poll job status hingga `completed` atau `failed`
- Jika gagal, ada pesan error yang jelas di `error_message`
- Output tersimpan di MinIO, bisa diakses via presigned URL

## Rate limits (per agent per menit)
- wasm: 100 req/menit
- headless: 20 req/menit  
- gui/desktop: 5 req/menit

## Batasan saat ini (Phase 2)
- Belum ada tool runner image (`platform-tools`) — step 4 gRPC akan gagal dial
- Step 5 output upload belum selesai implementasinya
- Desktop controller belum ada
- WASM executor belum ada
