package queue

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

// Handler is called for each message consumed from a stream.
type Handler func(ctx context.Context, msg JobMessage) error

// Consumer reads jobs from Redis Streams using a consumer group.
type Consumer struct {
	client        *redis.Client
	stream        string
	group         string
	consumerName  string
	blockDuration time.Duration
}

// NewConsumer creates a Consumer and ensures the consumer group exists.
func NewConsumer(redisURL, stream, group, consumerName string, blockMs int) (*Consumer, error) {
	opt, err := redis.ParseURL(redisURL)
	if err != nil {
		return nil, fmt.Errorf("parse redis url: %w", err)
	}
	c := &Consumer{
		client:        redis.NewClient(opt),
		stream:        stream,
		group:         group,
		consumerName:  consumerName,
		blockDuration: time.Duration(blockMs) * time.Millisecond,
	}

	// Create consumer group idempotently.
	err = c.client.XGroupCreateMkStream(context.Background(), stream, group, "0").Err()
	if err != nil && err.Error() != "BUSYGROUP Consumer Group name already exists" {
		return nil, fmt.Errorf("create consumer group: %w", err)
	}
	return c, nil
}

// Run starts a blocking read loop, calling handler for every message.
// Returns when ctx is cancelled.
func (c *Consumer) Run(ctx context.Context, handler Handler) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		streams, err := c.client.XReadGroup(ctx, &redis.XReadGroupArgs{
			Group:    c.group,
			Consumer: c.consumerName,
			Streams:  []string{c.stream, ">"},
			Count:    1,
			Block:    c.blockDuration,
		}).Result()
		if err == redis.Nil {
			continue // timeout, loop again
		}
		if err != nil {
			if ctx.Err() != nil {
				return ctx.Err()
			}
			return fmt.Errorf("xreadgroup: %w", err)
		}

		for _, s := range streams {
			for _, msg := range s.Messages {
				payload, ok := msg.Values["payload"].(string)
				if !ok {
					c.ack(ctx, msg.ID)
					continue
				}
				var job JobMessage
				if err := json.Unmarshal([]byte(payload), &job); err != nil {
					c.ack(ctx, msg.ID)
					continue
				}
				if err := handler(ctx, job); err != nil {
					// On error, leave message un-acked so it can be retried.
					continue
				}
				c.ack(ctx, msg.ID)
			}
		}
	}
}

func (c *Consumer) ack(ctx context.Context, id string) {
	_ = c.client.XAck(ctx, c.stream, c.group, id)
}

// Close shuts down the Redis client.
func (c *Consumer) Close() error { return c.client.Close() }
