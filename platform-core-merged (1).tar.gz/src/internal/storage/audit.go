package storage

import (
	"context"
	"encoding/json"
)

// AuditStore handles append-only audit log writes.
type AuditStore struct{ db *DB }

// NewAuditStore creates an AuditStore.
func NewAuditStore(db *DB) *AuditStore { return &AuditStore{db: db} }

// Write appends an audit event.
func (s *AuditStore) Write(ctx context.Context, eventType, entityID, agentID string, payload interface{}) error {
	var payloadJSON []byte
	if payload != nil {
		var err error
		payloadJSON, err = json.Marshal(payload)
		if err != nil {
			return err
		}
	}
	_, err := s.db.Pool.Exec(ctx, `
		INSERT INTO audit_log (event_type, entity_id, agent_id, payload)
		VALUES ($1, $2, $3, $4)`,
		eventType, entityID, agentID, payloadJSON,
	)
	return err
}
