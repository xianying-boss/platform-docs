package storage

import (
	"context"
	"time"
)

// DesktopSession represents a GUI desktop sandbox session.
type DesktopSession struct {
	SessionID     string     `json:"session_id"    db:"session_id"`
	AgentID       string     `json:"agent_id"      db:"agent_id"`
	SandboxName   string     `json:"sandbox_name"  db:"sandbox_name"`
	VNCURL        string     `json:"vnc_url"       db:"vnc_url"`
	Status        string     `json:"status"        db:"status"`
	LastHeartbeat *time.Time `json:"last_heartbeat" db:"last_heartbeat"`
	SnapshotRef   string     `json:"snapshot_ref"  db:"snapshot_ref"`
	CreatedAt     time.Time  `json:"created_at"    db:"created_at"`
	DestroyedAt   *time.Time `json:"destroyed_at"  db:"destroyed_at"`
}

// SessionStore handles desktop session persistence.
type SessionStore struct{ db *DB }

// NewSessionStore creates a SessionStore.
func NewSessionStore(db *DB) *SessionStore { return &SessionStore{db: db} }

// Create inserts a new desktop session record.
func (s *SessionStore) Create(ctx context.Context, sess *DesktopSession) error {
	_, err := s.db.Pool.Exec(ctx, `
		INSERT INTO desktop_sessions (agent_id, sandbox_name, status, created_at)
		VALUES ($1,$2,'creating',$3)
		RETURNING session_id::text`,
		sess.AgentID, sess.SandboxName, time.Now().UTC(),
	)
	return err
}

// Get returns a session by ID.
func (s *SessionStore) Get(ctx context.Context, sessionID string) (*DesktopSession, error) {
	sess := &DesktopSession{}
	err := s.db.Pool.QueryRow(ctx, `
		SELECT session_id::text, agent_id, sandbox_name,
		       COALESCE(vnc_url,''), status, last_heartbeat,
		       COALESCE(snapshot_ref,''), created_at, destroyed_at
		FROM desktop_sessions WHERE session_id=$1`,
		sessionID,
	).Scan(&sess.SessionID, &sess.AgentID, &sess.SandboxName,
		&sess.VNCURL, &sess.Status, &sess.LastHeartbeat,
		&sess.SnapshotRef, &sess.CreatedAt, &sess.DestroyedAt)
	return sess, err
}

// UpdateStatus updates a session's status and optional VNC URL.
func (s *SessionStore) UpdateStatus(ctx context.Context, sessionID, status, vncURL string) error {
	_, err := s.db.Pool.Exec(ctx, `
		UPDATE desktop_sessions
		SET status=$1, vnc_url=$2, last_heartbeat=now()
		WHERE session_id=$3`,
		status, vncURL, sessionID,
	)
	return err
}

// Destroy marks a session as destroyed.
func (s *SessionStore) Destroy(ctx context.Context, sessionID string) error {
	_, err := s.db.Pool.Exec(ctx, `
		UPDATE desktop_sessions SET status='destroyed', destroyed_at=now()
		WHERE session_id=$1`, sessionID)
	return err
}
