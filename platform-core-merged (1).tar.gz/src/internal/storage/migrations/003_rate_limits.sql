-- 003_rate_limits.sql
CREATE TABLE IF NOT EXISTS rate_limits (
    agent_id       TEXT        NOT NULL,
    tier           TEXT        NOT NULL,
    bucket_tokens  INT         NOT NULL DEFAULT 100,
    max_tokens     INT         NOT NULL DEFAULT 100,
    refill_rate    INT         NOT NULL DEFAULT 100,
    last_refill_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (agent_id, tier)
);
