-- 004_audit_log.sql
CREATE TABLE IF NOT EXISTS audit_log (
    log_id      BIGSERIAL   PRIMARY KEY,
    agent_id    TEXT        NOT NULL,
    tool_name   TEXT        NOT NULL,
    job_id      UUID,
    input_hash  TEXT,
    ip_address  TEXT,
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_agent ON audit_log(agent_id);
CREATE INDEX IF NOT EXISTS idx_audit_ts    ON audit_log(timestamp DESC);
