-- 001_init.sql
-- Core tables: tools, jobs, artifacts

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS tools (
    tool_name        TEXT PRIMARY KEY,
    tier             TEXT        NOT NULL CHECK (tier IN ('wasm','headless','gui')),
    phase            INT         NOT NULL DEFAULT 1,
    container_image  TEXT,
    wasm_path        TEXT,
    input_schema     JSONB,
    output_schema    JSONB,
    timeout_ms       INT         NOT NULL DEFAULT 30000,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS jobs (
    job_id           UUID        PRIMARY KEY,
    tool_name        TEXT        NOT NULL,
    tier             TEXT        NOT NULL,
    agent_id         TEXT        NOT NULL,
    status           TEXT        NOT NULL DEFAULT 'pending'
                                 CHECK (status IN ('pending','running','completed','failed')),
    input_hash       TEXT,
    input_json       BYTEA,
    output_ref       TEXT,
    logs             TEXT,
    duration_ms      INT,
    error_message    TEXT,
    callback_url     TEXT,
    sandbox_name     TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_jobs_agent_id   ON jobs(agent_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status     ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_created_at ON jobs(created_at DESC);

CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id       UUID        REFERENCES jobs(job_id) ON DELETE CASCADE,
    filename     TEXT        NOT NULL,
    minio_key    TEXT        NOT NULL,
    size_bytes   BIGINT,
    checksum     TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_artifacts_job_id ON artifacts(job_id);
