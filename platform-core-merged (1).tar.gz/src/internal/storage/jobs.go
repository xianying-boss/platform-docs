package storage

import (
	"context"
	"time"
)

// JobStatus represents the lifecycle state of a job.
type JobStatus string

const (
	JobStatusPending   JobStatus = "pending"
	JobStatusRunning   JobStatus = "running"
	JobStatusCompleted JobStatus = "completed"
	JobStatusFailed    JobStatus = "failed"
)

// Job is a single tool execution request.
type Job struct {
	JobID       string     `db:"job_id"`
	ToolName    string     `db:"tool_name"`
	Tier        string     `db:"tier"` // wasm | headless | gui
	AgentID     string     `db:"agent_id"`
	Status      JobStatus  `db:"status"`
	InputHash   string     `db:"input_hash"`
	InputJSON   []byte     `db:"input_json"`
	OutputRef   string     `db:"output_ref"` // MinIO prefix
	Logs        string     `db:"logs"`
	DurationMs  int        `db:"duration_ms"`
	ErrMessage  string     `db:"error_message"`
	CallbackURL string     `db:"callback_url"`
	SandboxName string     `db:"sandbox_name"`
	CreatedAt   time.Time  `db:"created_at"`
	CompletedAt *time.Time `db:"completed_at"`
}

// JobStore handles job persistence.
type JobStore struct{ db *DB }

// NewJobStore creates a JobStore.
func NewJobStore(db *DB) *JobStore { return &JobStore{db: db} }

// Create inserts a new job row (status=pending).
func (s *JobStore) Create(ctx context.Context, j *Job) error {
	_, err := s.db.Pool.Exec(ctx, `
		INSERT INTO jobs
		  (job_id, tool_name, tier, agent_id, status, input_hash, input_json, callback_url, created_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
		j.JobID, j.ToolName, j.Tier, j.AgentID, JobStatusPending,
		j.InputHash, j.InputJSON, j.CallbackURL, time.Now().UTC(),
	)
	return err
}

// SetRunning marks a job as running and records the sandbox name.
func (s *JobStore) SetRunning(ctx context.Context, jobID, sandboxName string) error {
	_, err := s.db.Pool.Exec(ctx,
		`UPDATE jobs SET status=$1, sandbox_name=$2 WHERE job_id=$3`,
		JobStatusRunning, sandboxName, jobID,
	)
	return err
}

// Complete marks a job as completed with output ref and duration.
func (s *JobStore) Complete(ctx context.Context, jobID, outputRef string, durationMs int, logs string) error {
	now := time.Now().UTC()
	_, err := s.db.Pool.Exec(ctx, `
		UPDATE jobs
		SET status=$1, output_ref=$2, duration_ms=$3, logs=$4, completed_at=$5
		WHERE job_id=$6`,
		JobStatusCompleted, outputRef, durationMs, logs, now, jobID,
	)
	return err
}

// Fail marks a job as failed with an error message.
func (s *JobStore) Fail(ctx context.Context, jobID, errMsg string) error {
	now := time.Now().UTC()
	_, err := s.db.Pool.Exec(ctx,
		`UPDATE jobs SET status=$1, error_message=$2, completed_at=$3 WHERE job_id=$4`,
		JobStatusFailed, errMsg, now, jobID,
	)
	return err
}

// Get returns a single job by ID.
func (s *JobStore) Get(ctx context.Context, jobID string) (*Job, error) {
	row, err := s.db.Pool.Query(ctx,
		`SELECT job_id, tool_name, tier, agent_id, status, input_hash, output_ref,
		        logs, duration_ms, error_message, callback_url, sandbox_name, created_at, completed_at
		 FROM jobs WHERE job_id=$1`, jobID)
	if err != nil {
		return nil, err
	}
	defer row.Close()

	if !row.Next() {
		return nil, nil
	}
	j := &Job{}
	err = row.Scan(
		&j.JobID, &j.ToolName, &j.Tier, &j.AgentID, &j.Status,
		&j.InputHash, &j.OutputRef, &j.Logs, &j.DurationMs,
		&j.ErrMessage, &j.CallbackURL, &j.SandboxName,
		&j.CreatedAt, &j.CompletedAt,
	)
	return j, err
}
