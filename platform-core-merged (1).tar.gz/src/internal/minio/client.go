package minio

import (
	"context"
	"fmt"
	"io"
	"net/url"
	"time"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

// Client wraps the MinIO SDK with helpers for platform operations.
type Client struct {
	mc     *minio.Client
	bucket string
}

// New creates a MinIO Client.
func New(endpoint, accessKey, secretKey, bucket string, useSSL bool) (*Client, error) {
	mc, err := minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(accessKey, secretKey, ""),
		Secure: useSSL,
	})
	if err != nil {
		return nil, fmt.Errorf("minio.New: %w", err)
	}
	return &Client{mc: mc, bucket: bucket}, nil
}

// EnsureBucket creates the bucket if it does not exist.
func (c *Client) EnsureBucket(ctx context.Context, region string) error {
	exists, err := c.mc.BucketExists(ctx, c.bucket)
	if err != nil {
		return err
	}
	if !exists {
		return c.mc.MakeBucket(ctx, c.bucket, minio.MakeBucketOptions{Region: region})
	}
	return nil
}

// Put uploads a reader to the given object key.
func (c *Client) Put(ctx context.Context, key string, r io.Reader, size int64, contentType string) error {
	_, err := c.mc.PutObject(ctx, c.bucket, key, r, size, minio.PutObjectOptions{
		ContentType: contentType,
	})
	return err
}

// Get downloads an object and returns a ReadCloser. Caller must close it.
func (c *Client) Get(ctx context.Context, key string) (io.ReadCloser, error) {
	obj, err := c.mc.GetObject(ctx, c.bucket, key, minio.GetObjectOptions{})
	if err != nil {
		return nil, err
	}
	return obj, nil
}

// PresignGet returns a presigned GET URL valid for the given duration.
func (c *Client) PresignGet(ctx context.Context, key string, ttl time.Duration) (*url.URL, error) {
	return c.mc.PresignedGetObject(ctx, c.bucket, key, ttl, url.Values{})
}

// PresignPut returns a presigned PUT URL valid for the given duration.
func (c *Client) PresignPut(ctx context.Context, key string, ttl time.Duration) (*url.URL, error) {
	return c.mc.PresignedPutObject(ctx, c.bucket, key, ttl)
}

// JobOutputPrefix returns the MinIO prefix for a job's output files.
func JobOutputPrefix(jobID string) string {
	return fmt.Sprintf("jobs/%s/output/", jobID)
}

// ArtifactKey returns the MinIO key for a named artifact.
func ArtifactKey(artifactID string) string {
	return fmt.Sprintf("artifacts/%s", artifactID)
}
