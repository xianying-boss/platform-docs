package telemetry

import (
	"context"
	"fmt"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.26.0"
	"go.opentelemetry.io/otel/trace"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var tracer trace.Tracer

// Init initialises the global OTel tracer provider and returns a shutdown func.
func Init(ctx context.Context, serviceName, otlpEndpoint string, insecureTLS bool) (func(context.Context) error, error) {
	opts := []otlptracegrpc.Option{
		otlptracegrpc.WithEndpoint(otlpEndpoint),
	}
	if insecureTLS {
		opts = append(opts, otlptracegrpc.WithDialOption(grpc.WithTransportCredentials(insecure.NewCredentials())))
	}

	exporter, err := otlptracegrpc.New(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("otlp exporter: %w", err)
	}

	res, err := resource.New(ctx,
		resource.WithAttributes(semconv.ServiceNameKey.String(serviceName)),
	)
	if err != nil {
		return nil, fmt.Errorf("otel resource: %w", err)
	}

	tp := sdktrace.NewTracerProvider(
		sdktrace.WithBatcher(exporter),
		sdktrace.WithResource(res),
	)
	otel.SetTracerProvider(tp)

	tracer = tp.Tracer(serviceName)
	return tp.Shutdown, nil
}

// Tracer returns the initialised tracer (or a no-op if Init was not called).
func Tracer() trace.Tracer {
	if tracer == nil {
		return otel.GetTracerProvider().Tracer("platform-core")
	}
	return tracer
}

// Start is a convenience wrapper around tracer.Start.
func Start(ctx context.Context, spanName string) (context.Context, trace.Span) {
	return Tracer().Start(ctx, spanName)
}
