package gateway

import (
	"context"
	"fmt"
	"net/http"
	"time"
)

// Server wraps an HTTP server with graceful shutdown.
type Server struct {
	srv *http.Server
}

// NewServer creates a Server on the given port.
func NewServer(port int, handler http.Handler, shutdownTimeout time.Duration) *Server {
	return &Server{
		srv: &http.Server{
			Addr:         fmt.Sprintf(":%d", port),
			Handler:      handler,
			ReadTimeout:  30 * time.Second,
			WriteTimeout: 60 * time.Second,
			IdleTimeout:  120 * time.Second,
		},
	}
}

// Start listens and serves. Returns when the server stops.
func (s *Server) Start() error {
	return s.srv.ListenAndServe()
}

// Shutdown gracefully stops the server.
func (s *Server) Shutdown(ctx context.Context) error {
	return s.srv.Shutdown(ctx)
}
