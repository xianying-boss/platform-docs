package handlers

import (
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"

	"platform-core/internal/storage"
)

// contextKey is a typed key for request context values.
type contextKey string

const contextKeyAgentID contextKey = "agent_id"

// ContextKeyAgentID is exported for use by middleware.
var ContextKeyAgentID = contextKeyAgentID

// JobHandler handles GET /v1/jobs/:id.
type JobHandler struct {
	jobStore *storage.JobStore
}

// NewJobHandler creates a JobHandler.
func NewJobHandler(jobStore *storage.JobStore) *JobHandler {
	return &JobHandler{jobStore: jobStore}
}

// ServeHTTP returns the current status and result of a job.
func (h *JobHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	jobID := chi.URLParam(r, "id")
	if jobID == "" {
		writeError(w, http.StatusBadRequest, "missing job id")
		return
	}

	job, err := h.jobStore.Get(r.Context(), jobID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "storage error")
		return
	}
	if job == nil {
		writeError(w, http.StatusNotFound, "job not found")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(job)
}

// HealthHandler handles GET /v1/health.
type HealthHandler struct{}

func (h *HealthHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write([]byte(`{"status":"ok"}`))
}

// writeError writes a JSON error response.
func writeError(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": msg})
}
