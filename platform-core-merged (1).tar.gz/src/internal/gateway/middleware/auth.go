package middleware

import (
	"context"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"net/http"
	"strings"

	"github.com/golang-jwt/jwt/v5"

	"platform-core/internal/gateway/handlers"
)

// Auth returns a JWT-validating middleware using the provided RSA public key PEM.
// If publicKeyPEM is nil (dev mode), JWT validation is SKIPPED and a synthetic
// agent_id "dev-agent" is injected into the context. NEVER use nil in production.
func Auth(publicKeyPEM []byte) func(http.Handler) http.Handler {
	// Dev mode: no public key → skip JWT validation entirely
	if publicKeyPEM == nil {
		return func(next http.Handler) http.Handler {
			return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				ctx := context.WithValue(r.Context(), handlers.ContextKeyAgentID, "dev-agent")
				next.ServeHTTP(w, r.WithContext(ctx))
			})
		}
	}

	pubKey, err := parseRSAPublicKey(publicKeyPEM)
	if err != nil {
		panic(fmt.Sprintf("invalid JWT public key: %v", err))
	}

	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Always allow health endpoint without token
			if r.URL.Path == "/v1/health" {
				next.ServeHTTP(w, r)
				return
			}
			authHeader := r.Header.Get("Authorization")
			if authHeader == "" || !strings.HasPrefix(authHeader, "Bearer ") {
				http.Error(w, `{"error":"missing authorization header"}`, http.StatusUnauthorized)
				return
			}
			tokenStr := strings.TrimPrefix(authHeader, "Bearer ")

			token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (interface{}, error) {
				if _, ok := t.Method.(*jwt.SigningMethodRSA); !ok {
					return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
				}
				return pubKey, nil
			})
			if err != nil || !token.Valid {
				http.Error(w, `{"error":"invalid token"}`, http.StatusUnauthorized)
				return
			}

			claims, ok := token.Claims.(jwt.MapClaims)
			if !ok {
				http.Error(w, `{"error":"invalid claims"}`, http.StatusUnauthorized)
				return
			}

			agentID, _ := claims["agent_id"].(string)
			ctx := context.WithValue(r.Context(), handlers.ContextKeyAgentID, agentID)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

func parseRSAPublicKey(pemBytes []byte) (*rsa.PublicKey, error) {
	block, _ := pem.Decode(pemBytes)
	if block == nil {
		return nil, fmt.Errorf("failed to decode PEM block")
	}
	key, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	rsaKey, ok := key.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("not an RSA public key")
	}
	return rsaKey, nil
}
