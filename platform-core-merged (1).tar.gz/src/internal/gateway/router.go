package gateway

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	chimiddleware "github.com/go-chi/chi/v5/middleware"
	"github.com/redis/go-redis/v9"
	"github.com/spf13/viper"

	"platform-core/internal/gateway/handlers"
	"platform-core/internal/gateway/middleware"
	"platform-core/internal/queue"
	"platform-core/internal/storage"
)

// NewRouter builds the Chi router with all routes and middleware.
func NewRouter(
	producer *queue.Producer,
	jobStore *storage.JobStore,
	jwtPublicKeyPEM []byte,
) http.Handler {
	r := chi.NewRouter()

	// ── Global middleware ───────────────────────────────────────────────────
	r.Use(chimiddleware.RequestID)
	r.Use(chimiddleware.RealIP)
	r.Use(chimiddleware.Recoverer)
	r.Use(middleware.Telemetry)

	// ── Redis client for rate limiter ───────────────────────────────────────
	redisOpt, _ := redis.ParseURL(viper.GetString("queue.redis_url"))
	rdb := redis.NewClient(redisOpt)

	rateLimits := middleware.RateLimits{
		WasmPerMinute:    viper.GetInt("rate_limits.wasm_per_minute"),
		AsyncPerMinute:   viper.GetInt("rate_limits.async_per_minute"),
		DesktopPerMinute: viper.GetInt("rate_limits.desktop_per_minute"),
	}
	// Sensible defaults if config not set
	if rateLimits.WasmPerMinute == 0 {
		rateLimits.WasmPerMinute = 100
	}
	if rateLimits.AsyncPerMinute == 0 {
		rateLimits.AsyncPerMinute = 20
	}
	if rateLimits.DesktopPerMinute == 0 {
		rateLimits.DesktopPerMinute = 5
	}

	// ── Public routes ───────────────────────────────────────────────────────
	r.Get("/v1/health", (&handlers.HealthHandler{}).ServeHTTP)

	// ── Authenticated + rate-limited routes ─────────────────────────────────
	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(jwtPublicKeyPEM))
		r.Use(middleware.RateLimit(rdb, rateLimits))

		execHandler := handlers.NewExecutionHandler(producer, jobStore)
		jobHandler := handlers.NewJobHandler(jobStore)

		r.Post("/v1/execute", execHandler.ServeHTTP)
		r.Get("/v1/jobs/{id}", jobHandler.ServeHTTP)
	})

	return r
}
