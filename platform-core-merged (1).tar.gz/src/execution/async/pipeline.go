package async

import (
	"context"
	"fmt"
	"time"

	"platform-core/execution/async/steps"
	"platform-core/internal/orchestration/code_controller"
	"platform-core/internal/queue"
	"platform-core/internal/storage"
	"platform-core/internal/telemetry"
)

// PipelineConfig holds all dependencies injected into the pipeline.
type PipelineConfig struct {
	SandboxClient *code_controller.SandboxClient
	JobStore      *storage.JobStore
	MinioEndpoint string
	MinioBucket   string
	MinioKey      string
	MinioSecret   string
	MinioUseSSL   bool
	Namespace     string
	Phase         int // 2=runc, 3=gvisor, 4=kata-fc
}

// runtimeClassForPhase maps platform phase to K8s runtimeClassName.
func runtimeClassForPhase(phase int) string {
	switch phase {
	case 3:
		return "gvisor"
	case 4:
		return "kata-fc"
	default:
		return "runc"
	}
}

// sandboxTemplateForPhase returns the SandboxTemplate name based on phase.
func sandboxTemplateForPhase(phase int) string {
	switch phase {
	case 3:
		return "code-headless-gvisor"
	case 4:
		return "code-headless-kata-fc"
	default:
		return "code-headless-runc"
	}
}

// Pipeline orchestrates the 5-step code execution flow.
type Pipeline struct {
	cfg *PipelineConfig
}

// NewPipeline creates a Pipeline with the given config.
func NewPipeline(cfg *PipelineConfig) *Pipeline {
	return &Pipeline{cfg: cfg}
}

// Run executes all 5 steps in sequence.
// On any failure, it runs cleanup and marks the job as failed.
func (p *Pipeline) Run(ctx context.Context, msg queue.JobMessage) error {
	ctx, span := telemetry.Start(ctx, "pipeline.run")
	defer span.End()

	pCtx := &steps.PipelineContext{
		Job:       &msg,
		StartTime: time.Now(),
	}

	// Mark job running in storage.
	if err := p.cfg.JobStore.SetRunning(ctx, msg.JobID, ""); err != nil {
		return fmt.Errorf("mark running: %w", err)
	}

	// ── Step 1: Create Runtime ───────────────────────────────────────────
	s1 := steps.NewCreateRuntime(
		p.cfg.SandboxClient,
		sandboxTemplateForPhase(p.cfg.Phase),
		runtimeClassForPhase(p.cfg.Phase),
	)
	if err := s1.Run(ctx, pCtx); err != nil {
		return p.fail(ctx, msg.JobID, "create_runtime", err)
	}
	// Update sandbox name in jobs table.
	_ = p.cfg.JobStore.SetRunning(ctx, msg.JobID, pCtx.SandboxName)

	// ── Step 2: Download Artifact ────────────────────────────────────────
	s2 := steps.NewDownloadArtifact(
		p.cfg.MinioEndpoint, p.cfg.MinioBucket,
		p.cfg.MinioKey, p.cfg.MinioSecret, p.cfg.MinioUseSSL,
	)
	if err := s2.Run(ctx, pCtx); err != nil {
		p.cleanup(ctx, msg.JobID)
		return p.fail(ctx, msg.JobID, "download_artifact", err)
	}

	// ── Step 3: Mount Skill ──────────────────────────────────────────────
	s3 := steps.NewMountSkill()
	if err := s3.Run(ctx, pCtx); err != nil {
		p.cleanup(ctx, msg.JobID)
		return p.fail(ctx, msg.JobID, "mount_skill", err)
	}

	// ── Step 4: Execute Code ─────────────────────────────────────────────
	s4 := steps.NewExecuteCode(pCtx.GRPCAddr)
	if err := s4.Run(ctx, pCtx); err != nil {
		p.cleanup(ctx, msg.JobID)
		return p.fail(ctx, msg.JobID, "execute_code", err)
	}

	// ── Step 5: Upload Output ────────────────────────────────────────────
	s5 := steps.NewUploadOutput(
		p.cfg.MinioEndpoint, p.cfg.MinioBucket,
		p.cfg.MinioKey, p.cfg.MinioSecret, p.cfg.MinioUseSSL,
	)
	if err := s5.Run(ctx, pCtx); err != nil {
		p.cleanup(ctx, msg.JobID)
		return p.fail(ctx, msg.JobID, "upload_output", err)
	}

	// ── Complete ─────────────────────────────────────────────────────────
	durationMs := int(time.Since(pCtx.StartTime).Milliseconds())
	if err := p.cfg.JobStore.Complete(ctx, msg.JobID, pCtx.OutputPrefix, durationMs, pCtx.Logs); err != nil {
		return fmt.Errorf("mark complete: %w", err)
	}

	// Always clean up the sandbox claim after execution.
	p.cleanup(ctx, msg.JobID)
	return nil
}

// fail marks the job failed and cleans up the sandbox.
func (p *Pipeline) fail(ctx context.Context, jobID, step string, err error) error {
	msg := fmt.Sprintf("step %s: %v", step, err)
	_ = p.cfg.JobStore.Fail(ctx, jobID, msg)
	return fmt.Errorf("%s", msg)
}

// cleanup deletes the SandboxClaim so the warm pod returns to the pool.
func (p *Pipeline) cleanup(ctx context.Context, jobID string) {
	_ = p.cfg.SandboxClient.DeleteClaim(ctx, jobID)
}
