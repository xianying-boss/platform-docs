package steps

import (
	"context"
	"fmt"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	execpb "platform-core/api/proto/execution"
	"platform-core/internal/telemetry"
)

// ExecuteCode dials the sandbox gRPC server and runs the tool.
type ExecuteCode struct {
	grpcAddr string
}

func NewExecuteCode(grpcAddr string) *ExecuteCode {
	return &ExecuteCode{grpcAddr: grpcAddr}
}

func (s *ExecuteCode) Run(ctx context.Context, pCtx *PipelineContext) error {
	ctx, span := telemetry.Start(ctx, "step.execute_code")
	defer span.End()

	// Default 30s timeout; tools may override via input field.
	timeoutMs := int32(30_000)

	conn, err := grpc.NewClient(
		s.grpcAddr,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithBlock(),
		grpc.WithTimeout(15*time.Second),
	)
	if err != nil {
		return fmt.Errorf("dial sandbox %s: %w", s.grpcAddr, err)
	}
	defer conn.Close()

	client := execpb.NewExecutionServiceClient(conn)

	req := &execpb.ExecuteRequest{
		JobId:     pCtx.Job.JobID,
		ToolName:  pCtx.Job.ToolName,
		InputJson: []byte(pCtx.Job.InputJSON),
		TimeoutMs: timeoutMs,
	}

	res, err := client.Execute(ctx, req)
	if err != nil {
		return fmt.Errorf("execute rpc: %w", err)
	}

	pCtx.Logs = res.Stdout + res.Stderr

	if res.ExitCode != 0 {
		return fmt.Errorf("tool exited %d: %s", res.ExitCode, res.Stderr)
	}
	return nil
}
