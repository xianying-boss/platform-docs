package steps

import (
	"context"
	"fmt"

	"platform-core/internal/telemetry"
)

// ─────────────────────────────────────────────────────────
// Step 3: MountSkill
// ─────────────────────────────────────────────────────────

// MountSkill ensures the correct tool binary/script is available inside
// the sandbox. In Phase 2 the tool image is baked into the SandboxTemplate;
// this step is a no-op placeholder that future phases will use to inject
// dynamic tool layers via initContainers.
type MountSkill struct{}

func NewMountSkill() *MountSkill { return &MountSkill{} }

func (s *MountSkill) Run(ctx context.Context, pCtx *PipelineContext) error {
	_, span := telemetry.Start(ctx, "step.mount_skill")
	defer span.End()
	// Phase 2: tool image is pre-baked into the SandboxTemplate container image.
	// Future: dynamically inject tool layer via K8s ephemeral containers or
	// initContainer that copies /skill/. from a tool-specific OCI image.
	return nil
}
