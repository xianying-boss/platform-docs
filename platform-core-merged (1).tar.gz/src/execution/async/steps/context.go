package steps

import (
	"time"

	corev1 "k8s.io/api/core/v1"

	"platform-core/internal/queue"
)

// PipelineContext carries mutable state shared across all pipeline steps.
// It is passed by pointer so each step can mutate it.
type PipelineContext struct {
	Job          *queue.JobMessage
	SandboxName  string         // Populated by Step 1
	ClaimName    string         // "job-<JobID>"
	GRPCAddr     string         // Populated by Step 1 after sandbox is ready
	OutputPrefix string         // Populated by Step 5
	StartTime    time.Time
	Logs         string         // Accumulated stdout/stderr from Step 4
	EnvVars      []corev1.EnvVar // Populated by Step 2 (artifact URLs)
}
