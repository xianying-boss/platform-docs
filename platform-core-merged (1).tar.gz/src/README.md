# platform-core

> Control plane + execution engine for the Tool Execution Platform.  
> Go 1.23 · Chi v5 · kubernetes-sigs/agent-sandbox · Redis Streams · PostgreSQL 16 · MinIO

---

## Quick Start (5 steps)

### 1. Start local infra
```bash
make up
# starts postgres:5432 + redis:6379 + minio:9000
```

### 2. Create kind cluster + install agent-sandbox
```bash
make kind-create
make install-sandbox
make apply-crds
```

### 3. Build
```bash
go mod tidy
make build
```

### 4. Run (two terminals)
```bash
# Terminal 1
make run-gateway
# → listens on :8080, auto-migrates DB, prints DEV MODE warning (no JWT needed)

# Terminal 2  
make run-orchestrator
# → connects to K8s, bootstraps SandboxTemplate + WarmPool, consumes Redis stream
```

### 5. Test
```bash
make smoke               # GET /v1/health → {"status":"ok"}
make smoke-execute       # POST /v1/execute → {"job_id":"..."}

# Poll job status
curl http://localhost:8080/v1/jobs/<job_id> | jq .
```

---

## Architecture

```
Agent/Client
    │
    ▼ POST /v1/execute
┌──────────────────────────────────────────┐
│  Gateway  :8080                          │
│  JWT RS256 · Redis Lua rate-limit · OTel │
└──────────────────┬───────────────────────┘
                   │ tier=headless → Redis XADD "code-jobs"
                   │ tier=wasm    → in-process (TODO)
                   ▼
┌──────────────────────────────────────────┐
│  Orchestrator                            │
│  Redis XREADGROUP · 5-step pipeline      │
└──────────────────┬───────────────────────┘
                   │ SandboxClaim CRD
                   ▼
┌──────────────────────────────────────────┐
│  agent-sandbox controller                │
│  (kubernetes-sigs/agent-sandbox v0.1.1)  │
└──────────────────┬───────────────────────┘
                   │ allocates warm pod
                   ▼
┌──────────────────────────────────────────┐
│  Tool Runner pod  :50051 gRPC            │
│  (platform-tools image)                  │
└──────────────────────────────────────────┘
```

---

## Pipeline steps

| Step | File | What it does |
|------|------|--------------|
| 1 | `steps/1_create_runtime.go` | Create `SandboxClaim`, wait for pod `Ready` (30s) |
| 2 | `steps/2_download_artifact.go` | Presign MinIO URLs → inject as `ARTIFACT_N_URL` env vars |
| 3 | `steps/3_mount_skill.go` | No-op phase 2; phase 3+ injects tool layer via initContainers |
| 4 | `steps/4_execute_code.go` | Dial sandbox gRPC `:50051`, send `ExecuteRequest` proto |
| 5 | `steps/5_upload_output.go` | Collect output from sandbox → upload to MinIO |

Any step failure → sandbox cleanup + job marked `failed`.

---

## Key design decisions (from merge)

| Feature | Source | Detail |
|---------|--------|--------|
| JWT auth | zip | RS256 public key PEM; dev mode skips validation if key file missing |
| Rate limiting | zip | Redis Lua script — atomic token bucket, avoids race conditions |
| `sandbox_client.go` | zip | `EnsureTemplate`, `EnsureWarmPool`, `CreateClaim`, `WaitForClaim`, `PauseSandbox`, `ResumeSandbox`, `DeleteClaim` |
| Auto-migration | mine | `db.Migrate(ctx)` on startup — no manual `make migrate` step |
| Session/Artifact/Audit tables | mine | `storage.SessionStore`, `ArtifactStore`, `AuditStore` |
| OTel tracing | zip | Full OTLP gRPC export, span per pipeline step |
| K8s bootstrap | zip | Orchestrator ensures `SandboxTemplate` + `WarmPool` exist at startup |

---

## Configuration (`config/app.yaml`)

```yaml
platform:
  phase: 2      # 2=runc  3=gVisor  4=kata-fc (Firecracker)
  namespace: default

storage:
  postgres_dsn: "postgres://platform:platform@localhost:5432/platform?sslmode=disable"
  minio_endpoint: "localhost:9000"

queue:
  redis_url: "redis://localhost:6379"
  code_stream: "code-jobs"

vault:
  jwt_public_key_path: "/etc/platform/jwt_public.pem"  # omit for dev mode
```

---

## Production JWT setup

```bash
# Generate RSA key pair
openssl genrsa -out private.pem 4096
openssl rsa -in private.pem -pubout -out public.pem

# Place public key where gateway can read it
cp public.pem /etc/platform/jwt_public.pem

# Issue a token for an agent (private key stays on auth service)
go run ./cmd/gateway -issue-token agent-001   # uses internal/auth.IssueToken
```

---

## Adding a new tool

1. Add a row to the `tools` table: `INSERT INTO tools (tool_name, tier, container_image) VALUES ('my_tool', 'headless', 'gcr.io/platform/my-tool:latest');`
2. Build and push `platform-tools/my_tool` image
3. Update `SandboxTemplate` image ref → WarmPool rolls automatically

---

## File tree

```
cmd/
  gateway/main.go          ← HTTP API (port 8080)
  orchestrator/main.go     ← Queue consumer + K8s bootstrap
internal/
  auth/jwt.go              ← RS256 token verify + issue (dev)
  gateway/
    server.go              ← HTTP server + graceful shutdown
    router.go              ← Chi routes + rate-limit wiring
    handlers/execution.go  ← POST /v1/execute
    handlers/jobs.go       ← GET /v1/jobs/:id + health
    middleware/auth.go     ← JWT RS256 (nil = dev mode skip)
    middleware/ratelimit.go ← Redis Lua token bucket
    middleware/telemetry.go ← OTel span per request
  orchestration/code_controller/
    sandbox_client.go      ← Full agent-sandbox CRD client
  queue/
    producer.go            ← Redis XADD
    consumer.go            ← Redis XREADGROUP
  storage/
    db.go                  ← pgxpool connection
    migrate.go             ← Auto-migration (embed SQL)
    jobs.go                ← Job CRUD
    artifacts.go           ← Artifact CRUD
    sessions.go            ← Desktop session CRUD
    audit.go               ← Append-only audit log
    migrations/            ← 001..004 SQL files
  minio/client.go          ← MinIO S3 helpers
  telemetry/tracer.go      ← OTel OTLP init
execution/async/
  pipeline.go              ← 5-step orchestrator
  runner.go                ← Redis → pipeline dispatch
  steps/
    context.go             ← PipelineContext (shared state)
    1_create_runtime.go    ← SandboxClaim + WaitForClaim
    2_download_artifact.go ← MinIO presign → env vars
    3_mount_skill.go       ← No-op (phase 2)
    4_execute_code.go      ← gRPC ExecutionService.Execute
    5_upload_output.go     ← Collect output → MinIO
api/proto/execution.proto  ← gRPC service definition
config/
  app.yaml                 ← All config keys
  crd/sandbox_templates.yaml   ← 4 SandboxTemplate CRDs
  crd/sandbox_warm_pools.yaml  ← 4 SandboxWarmPool CRDs
  rbac/orchestrator_role.yaml  ← ServiceAccount + ClusterRole
infra/docker-compose/docker-compose.yml
hack/kind-config.yaml
```
